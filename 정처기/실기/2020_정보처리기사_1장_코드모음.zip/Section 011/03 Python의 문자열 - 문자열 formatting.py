name = 'mike'
num = 10
x = f"hello {name}, you're {num}th user"
print(x)