#include <stdio.h>
main()
{
	char a = 'A';
	char b[9] = "SINAGONG";
	char* c = "SINAGONG";
	printf("%c\n", a);
	printf("%s\n", b);
	printf("%s\n", c);
}