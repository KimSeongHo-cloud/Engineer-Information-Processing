#include <stdio.h>
main()
{
	int a[2][4] = {
	{10, 20, 30, 40},
	{50, 60, 70, 80} };
	printf("%d ", a[0][0]);
	printf("%d\n", a[1][1]);
}