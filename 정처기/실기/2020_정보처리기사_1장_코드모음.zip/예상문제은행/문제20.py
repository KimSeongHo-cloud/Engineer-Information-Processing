hap = 0
for i in range(1, 11):
    hap += i
print(i, hap)