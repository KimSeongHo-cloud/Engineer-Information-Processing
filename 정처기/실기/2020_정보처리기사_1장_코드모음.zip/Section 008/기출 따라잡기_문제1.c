#include <stdio.h>
main()
{
	char* str;
	str = "KOREA";
	printf("%8.3s\n", str);
}