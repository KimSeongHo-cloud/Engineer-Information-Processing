a = 15
if a > 10:
    a = a - 10
print(a)