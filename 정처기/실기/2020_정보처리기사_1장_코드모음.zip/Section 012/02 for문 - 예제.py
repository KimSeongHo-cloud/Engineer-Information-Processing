a = [ 35, 55, 65, 84, 45 ]
hap = 0
for i in a:
    hap += i
avg = hap / len(a)
print(hap, avg)