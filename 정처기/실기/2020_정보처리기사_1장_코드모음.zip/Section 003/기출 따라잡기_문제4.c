#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
main() {
	int i, j;
	scanf("%o#%x", &i, &j);
	printf("%d %d", i, j);
}