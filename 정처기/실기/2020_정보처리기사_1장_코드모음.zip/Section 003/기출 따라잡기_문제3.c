#include <stdio.h>
main() {
	float a = 3.45678f;
	double b = 0.0561214;
	printf("[a]=%.2f / [b]=%.3e", a, b);
}